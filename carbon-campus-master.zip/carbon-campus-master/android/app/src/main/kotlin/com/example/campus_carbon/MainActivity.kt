package com.example.campus_carbon

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
